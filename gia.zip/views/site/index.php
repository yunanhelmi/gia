<?php

/* @var $this yii\web\View */
use yii\helpers\url;

$this->title = 'APLIKASI GIA';
?>
<div class="site-index">

    <div class="jumbotron">
        
        <img src="img/logo GIA.gif" height="300" ></img>
        
    </div>

    <div class="body-content">

      

    </div>
</div>
