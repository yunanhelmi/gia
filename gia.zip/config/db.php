<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=gia',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8',
];
